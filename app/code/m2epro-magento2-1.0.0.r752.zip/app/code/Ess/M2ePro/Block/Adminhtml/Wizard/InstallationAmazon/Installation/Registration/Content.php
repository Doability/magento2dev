<?php

namespace Ess\M2ePro\Block\Adminhtml\Wizard\InstallationAmazon\Installation\Registration;

class Content extends \Ess\M2ePro\Block\Adminhtml\Wizard\Installation\Registration\Content
{
    //########################################

    //########################################
}