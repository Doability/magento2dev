<?php

namespace Ess\M2ePro\Block\Adminhtml\Wizard\Installation\ListingTutorial;

use Ess\M2ePro\Block\Adminhtml\Magento\AbstractBlock;

abstract class Content extends AbstractBlock
{
}