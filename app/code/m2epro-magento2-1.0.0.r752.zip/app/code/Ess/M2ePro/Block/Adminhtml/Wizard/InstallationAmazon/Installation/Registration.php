<?php

namespace Ess\M2ePro\Block\Adminhtml\Wizard\InstallationAmazon\Installation;

use Ess\M2ePro\Block\Adminhtml\Wizard\InstallationAmazon\Installation;

class Registration extends Installation
{
    //########################################

    protected function getStep()
    {
        return 'registration';
    }

    //########################################
}