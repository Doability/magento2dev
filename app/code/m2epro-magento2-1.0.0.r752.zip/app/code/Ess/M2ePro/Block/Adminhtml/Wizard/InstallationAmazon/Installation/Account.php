<?php

namespace Ess\M2ePro\Block\Adminhtml\Wizard\InstallationAmazon\Installation;

use Ess\M2ePro\Block\Adminhtml\Wizard\InstallationAmazon\Installation;

class Account extends Installation
{
    //########################################

    protected function getStep()
    {
        return 'account';
    }

    //########################################
}