<?php

namespace Ess\M2ePro\Block\Adminhtml\Wizard\InstallationEbay\Installation;

use Ess\M2ePro\Block\Adminhtml\Wizard\InstallationEbay\Installation;

class Registration extends Installation
{
    protected function getStep()
    {
        return 'registration';
    }
}