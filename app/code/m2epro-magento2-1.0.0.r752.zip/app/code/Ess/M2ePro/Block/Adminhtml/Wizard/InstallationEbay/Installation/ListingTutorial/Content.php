<?php

namespace Ess\M2ePro\Block\Adminhtml\Wizard\InstallationEbay\Installation\ListingTutorial;

class Content extends \Ess\M2ePro\Block\Adminhtml\Wizard\Installation\ListingTutorial\Content
{
    protected $_template = 'wizard/installationEbay/installation/listing_tutorial.phtml';

    //########################################
}