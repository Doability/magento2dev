<?php

namespace Ess\M2ePro\Block\Adminhtml\Wizard\MigrationFromMagento1\Installation\Congratulation;

use Ess\M2ePro\Block\Adminhtml\Magento\AbstractBlock;

class Content extends AbstractBlock
{
    protected $_template = 'wizard/migrationFromMagento1/installation/congratulation.phtml';
}