<?php

namespace Ess\M2ePro\Block\Adminhtml\Magento;

class Button extends \Magento\Backend\Block\Widget\Button
{
}