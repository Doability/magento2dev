<?php

namespace Ess\M2ePro\Block\Adminhtml\Wizard\MigrationFromMagento1\Installation\Welcome;

use Ess\M2ePro\Block\Adminhtml\Magento\AbstractBlock;

class Content extends AbstractBlock
{
    protected $_template = 'wizard/migrationFromMagento1/installation/welcome.phtml';
}