<?php

namespace Ess\M2ePro\Block\Adminhtml\Magento\Renderer;

abstract class AbstractRenderer
{
    abstract public function render();
}