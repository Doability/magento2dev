var config = {
    map: {
        '*': {
            searchAutocomplete: 'Mirasvit_SearchAutocomplete/js/autocomplete'
        }
    }
};